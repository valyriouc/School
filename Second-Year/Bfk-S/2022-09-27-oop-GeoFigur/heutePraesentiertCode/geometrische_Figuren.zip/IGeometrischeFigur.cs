﻿using System;
using System.Collections.Generic;
using System.Text;

namespace geometrische_Figuren
{
    interface IGeometrischeFigur
    {
        double BerechneFlaecheninhalt();
        string NamenDesFigurUndInhalten();
        string GetArtDesFigur();
    }
}
