﻿using System;

namespace geometrische_Figuren
{
    class Program
    {
        static void Main(string[] args)
        {
            TestGeoFigur test = new TestGeoFigur();
            test.erstellenRandomKreise(5);
            test.erstellenRandomQuadrat(5);
            test.erstellenRandomRechteck(5);

            test.SehenAllenDetailDesObjekts(test.GetKreisen());
            test.SehenAllenFlaecheninhaltDesFigurList(test.GetKreisen());

            test.SehenAllenDetailDesObjekts(test.GetQuadrats());
            test.SehenAllenFlaecheninhaltDesFigurList(test.GetQuadrats());

            test.SehenAllenDetailDesObjekts(test.GetRechtecks());
            test.SehenAllenFlaecheninhaltDesFigurList(test.GetRechtecks());
        }
    }
}
