﻿using System;
using System.Collections.Generic;
using System.Text;

namespace geometrische_Figuren
{
    static class Constants
    {
        public const double pi = 3.141592;
    }
}
