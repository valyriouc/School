﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04_arbeitsblatt_assoziationen_Lösung
{
    class Verkaeufer
    {
        //===============================
        // Attribute
        //===============================
        private int VID;
        private List<Artikel> sortiment = new List<Artikel>();


        //===============================
        // Konstruktor
        //===============================
        public Verkaeufer(int vid)
        {
            //Einen Konstruktor, der als Parameter einen ganzzahligen Wert vid erhält und damit die gleichnamige Instazvariable initialisiert.
            this.VID = vid;
        }

        //===============================
        // Methoden
        //===============================

        public double getPreis(int i)
        {
            //Eine Methode getPreis, die als Parameter einen ganzzahligen Wert i erhält.
            //getPreis soll als Rückgabewert den Preis des Artikels liefern, der innerhalb der Liste sortiment den Index i hat.
            return sortiment[i].getPreis();
        }
        public void setPreis(int i, double p)
        {
            //Eine Methode setPreis, die als Parameter einen ganzzahligen Wert i und den Fließkommawert p erhält.
            //setPreis setzt den Preis des Artikels, der innerhallb der Liste sortiment den Index i hat.
            sortiment[i].setPreis(p);
        }

        public void kaufen(int i, int b)
        {
            //Eine Methode kaufen, die als Parameter zwei ganzzahlige Werte i und b erhält.
            //kaufen soll den Bestand des Artikels, der innerhalb dre Liste sortiment den Index i hat, um b erhöhen.
            sortiment[i].kaufen(b);
        }

        public void rabatt(int s, int d)
        {
            //Eine Methode rabatt, die den Preis jedes Artikls innerhalb der Liste sortiment, dessen Bestand größer als s Exemplare ist, um den Prozentwert d reduziert.
            foreach(Artikel artikel in sortiment)
            {
                if(artikel.getBestand() > s)
                {
                    artikel.setPreis(d);
                }
            }
        }
        public void erweitereSortiment(int n)
        {
            //nicht notwendig
        }

        public void addArtikel(Artikel artikel)
        {
            //Eine Methode addArtikel, die als Parameter ein Artikel-Objekt erhält und dieses in die interne Liste hinzufügt.
            sortiment.Add(artikel);
        }
    }
}
