﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04_arbeitsblatt_assoziationen_Lösung
{
    class Program
    {
        static void Main(string[] args)
        {
            //===================
            // Verkäufer anlegen
            //===================
            Verkaeufer verkaeufer1 = new Verkaeufer(1);
            Verkaeufer verkaeufer2 = new Verkaeufer(2);

            //===================
            // Artikel anlegen
            //===================

            //Hose
            Artikel hose = new Artikel();
            verkaeufer1.addArtikel(hose);
            hose.setName("Hosen");
            hose.setCode("ho");
            hose.setBestand(300);
            hose.setPreis(120.00);

            //Schuhe
            Artikel schuhe = new Artikel();
            verkaeufer1.addArtikel(schuhe);
            schuhe.setName("Schuhe");
            schuhe.setCode("sh");
            schuhe.setBestand(400);
            schuhe.setPreis(98);

            //Tasche
            Artikel tasche = new Artikel();
            verkaeufer1.addArtikel(tasche);
            tasche.setName("Tasche");
            tasche.setCode("ta");
            tasche.setBestand(500);
            tasche.setPreis(33);

            //Mantel
            Artikel mantel = new Artikel();
            verkaeufer1.addArtikel(mantel);
            mantel.setName("Mantel");
            mantel.setCode("ma");
            mantel.setBestand(400);
            mantel.setPreis(55);

            //Socken
            Artikel socken = new Artikel();
            verkaeufer1.addArtikel(socken);
            socken.setName("Socken");
            socken.setCode("so");
            socken.setBestand(200);
            socken.setPreis(12);

            //Handschuhe
            Artikel handschuhe = new Artikel();
            verkaeufer2.addArtikel(handschuhe);
            handschuhe.setName("Handschuhe");
            handschuhe.setCode("hs");
            handschuhe.setBestand(100);
            handschuhe.setPreis(11);

            //Hemd
            Artikel hemd = new Artikel();
            verkaeufer2.addArtikel(hemd);
            hemd.setName("Hemd");
            hemd.setCode("he");
            hemd.setBestand(600);
            hemd.setPreis(22);

            //Jacke
            Artikel jacke = new Artikel();
            verkaeufer2.addArtikel(jacke);
            jacke.setName("Jacke");
            jacke.setCode("ja");
            jacke.setBestand(500);
            jacke.setPreis(122);

            //Gürtel
            Artikel gürtel = new Artikel();
            verkaeufer2.addArtikel(gürtel);
            gürtel.setName("Gürtel");
            gürtel.setCode("gu");
            gürtel.setBestand(300);
            gürtel.setPreis(32);

            Console.ReadKey();
        }
    }
}
