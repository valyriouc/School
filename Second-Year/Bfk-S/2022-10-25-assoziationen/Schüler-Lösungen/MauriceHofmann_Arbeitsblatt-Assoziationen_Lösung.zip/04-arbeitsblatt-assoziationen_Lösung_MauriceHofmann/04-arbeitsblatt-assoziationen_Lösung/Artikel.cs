﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _04_arbeitsblatt_assoziationen_Lösung
{
    class Artikel
    {
        //===============================
        // Attribute
        //===============================
        private string name;
        private string code;
        private int bestand;
        private double preis;

        //===============================
        // Konstruktor
        //===============================
        public Artikel()
        {

        }

        //===============================
        // Methoden
        //===============================
        public void setName(string n)
        {
            this.name = n;
        }
        public string getName()
        {
            return this.name;
        }


        public void setCode(string c)
        {
            this.code = c;
        }
        public string getCode()
        {
            return this.code;
        }


        public void setBestand(int s)
        {
            this.bestand = s;
        }
        public int getBestand()
        {
            return this.bestand;
        }


        public void setPreis(double p)
        {
            this.preis = p;
        }
        public double getPreis()
        {
            return this.preis;
        }

        public void kaufen(int b)
        {
            //Erstellen Sie für die Klasse Artikel die Methode kaufen, die zur Erhöhung des Bestandes eines Artikels dienen soll.
            //Hierzu wird ihr ein ganzzahliger Parameter übergeben, um den der Bestand eines Artikels erhöht wird

            this.bestand += b;
        }
    }
}
