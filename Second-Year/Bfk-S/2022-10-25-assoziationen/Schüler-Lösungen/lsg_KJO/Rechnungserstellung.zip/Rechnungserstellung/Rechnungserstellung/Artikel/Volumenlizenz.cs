﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rechnungserstellung.Artikel
{
	class Volumenlizenz : Artikel
	{
		//Attribute
		int anzahl;

		//Methods
		public Volumenlizenz(int anzahl,int nummer, string bezeichnung, double preis) : base(nummer, bezeichnung, preis)
		{
			if(anzahl<10)
			{
				anzahl = 10;
			}
			Console.WriteLine("Konstruktor von Volumenlizenz wird Aufgeluft ");
			this.anzahl = anzahl;
		}
		public override double getPreis()
		{
			return preis*0.9;
		}
		public override string ToString()
		{
			return string.Format
				(
				"Anzahl : {0}\n"
				+ "Artikelsnummer : {1}\n"
				+ "Bezeichnung : {2}\n"
				+ "Einzelpreis : {3}\n"
				,this.anzahl, getNummer(), getBezeichnung(), getPreis()
				);
		}
	}
}
