﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rechnungserstellung
{
	class Kunde
	{
		//Attributes
		private int kundennummer;
		private string name;
		private string strasse;
		private int plz;
		private string ort;

		//Constructor
		public Kunde(int kundennummer, string name, string strasse, int plz, string ort)
		{
			this.kundennummer = kundennummer;
			this.name = name;
			this.strasse = strasse;
			if (plz > 0 && plz < 100000)
			{
				this.plz = plz;
			}
			else this.plz = 99999;
		}
		//Methods
		public int getKundennummer(string name)
		{
			//warum parameter benoetig?????
			return kundennummer;
		}
		public string getName()
		{
			return name;
		}
		public int getPlz()
		{
			return plz;
		}
		public string getOrt()
		{
			return ort;
		}
		public string getStrasse()
		{
			return strasse;
		}
		public override string ToString()
		{
			return string.Format(
				"Kundennummer : {0}\n"
				+ "name : {1}\n"
				+ "strasse : {2}\n"
				+ "plz : {3}\n"
				,kundennummer,name,strasse,plz);
		}
	}
}