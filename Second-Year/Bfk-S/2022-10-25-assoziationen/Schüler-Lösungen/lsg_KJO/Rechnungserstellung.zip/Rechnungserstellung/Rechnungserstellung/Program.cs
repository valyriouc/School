﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rechnungserstellung
{
	class Program
	{
		static void Main(string[] args)
		{
			Kunde k1 = new Kunde(1,"Kyuhyun","NYstreet",12345,"USA");
			Rechnung re1 = new Rechnung(k1);

			Artikel.Einzellizenz el1 = new Artikel.Einzellizenz(1232,"Einzellizenz_1",100);
			Artikel.Volumenlizenz vl1 = new Artikel.Volumenlizenz(10,1232, "Einzellizenz_1", 100);

			re1.setArtikel(el1);
			re1.setArtikel(vl1);

			re1.drucken();
		}
	}
}
