﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rechnungserstellung
{
	class Rechnung
	{
		private Kunde kunde;
		private List<Artikel.Artikel> artikelliste = new List<Artikel.Artikel>(); 
		//Constructor
		public Rechnung(Kunde kunde)
		{
			this.kunde = kunde;
		}

		//Methods
		public double getGesamtbetrag()
		{
			double Summe=0.0;
			foreach(Artikel.Artikel el in artikelliste)
			{
				Summe += el.getPreis();
			}
			return Summe;
		}
		public void setArtikel(Artikel.Artikel artikel)
		{
			if(artikel!=null) artikelliste.Add(artikel);
		}
		public void drucken()
		{
			Console.WriteLine("\n===========RECHNUNG===========");
			Console.WriteLine("<Kundendaten>");
			Console.WriteLine(kunde.ToString());
			Console.WriteLine("<Artikelliste>");
			foreach(Artikel.Artikel el in artikelliste)
			{
				Console.WriteLine(el.ToString());
			}
			Console.WriteLine("===========RECHNUNG===========\n");
		}
	}
}
