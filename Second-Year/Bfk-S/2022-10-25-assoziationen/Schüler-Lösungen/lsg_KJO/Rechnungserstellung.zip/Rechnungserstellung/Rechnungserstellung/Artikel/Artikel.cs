﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rechnungserstellung.Artikel
{
	abstract class Artikel
	{
		//Attributes
		private int nummer;
		private string bezeichnung;
		protected double preis;

		//Constructor
		public Artikel(int nummer, string bezeichnung, double preis)
		{
			this.nummer = nummer;
			this.bezeichnung = bezeichnung;
			this.preis = preis;
		}

		//Methods
		public int getNummer()
		{
			return nummer;
		}
		public string getBezeichnung()
		{
			return bezeichnung;
		}
		public abstract double getPreis();
		public abstract string ToString();
	}
}