﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Rechnungserstellung.Artikel
{
	class Einzellizenz : Artikel
	{
		public Einzellizenz(int nummer, string bezeichnung, double preis) : base(nummer, bezeichnung, preis)
		{
			Console.WriteLine("Konstruktor von Einzellizenz wird Aufgeluft ");
		}
		public override double getPreis()
		{
			return preis*1.1;
		}
		public override string ToString()
		{
			return string.Format
				(
				"Artikelsnummer : {0}\n"
				+ "Bezeichnung : {1}\n"
				+ "Einzelpreis : {2}\n"
				, getNummer(),getBezeichnung(),getPreis()
				);
		}
	}
}
