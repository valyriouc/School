﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Medikamente
{
	class Tablettenform : Medikamentenform
	{
		private double pulverKoernungInUm;

		//Methods
		public Tablettenform(double gewichtInG, double laengeInMm, double breiteInMm, long id, double pulverKoernung):base(gewichtInG, laengeInMm, breiteInMm, id)
		{
			this.pulverKoernungInUm = pulverKoernung;
		}
		public override string wirkstofffreisetzung()
		{
			return string.Format
				(
				"Freisetzung des Wirkstoffes durch Zersetzung der Tablette.\n"+
				"Pulverkoernung in Mikrometer : {0}",pulverKoernungInUm
				);
		}
	}
}
