﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Medikamente
{
	class Medikament
	{
		private string haltbarkeitsdatum;
		private string name;
		private string wirksamkeit;
		private long id;

		private List<Medikamentenform> arznelForm = new List<Medikamentenform>();

		public Medikament(string haltbarkeitsdatum, string name, string wirksamkeit, Medikamentenform formInfos)
		{
			this.haltbarkeitsdatum = haltbarkeitsdatum;
			this.name = name;
			this.wirksamkeit = wirksamkeit;
			//id?????

			//sehen UML!! Diese Klasse muss 'Mindestens einen' Medikamentenform haben. 
			arznelForm.Add(formInfos);
		}
	}
}
