﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Medikamente
{
	class Blister
	{
		private int anzahlMulden;
		private int anzahlReihen;
		private int anzahlSpalten;
		private int anzahlMedikamente=0;
		private long id;
		//achten zwei demension Array in C#
		//In diesem aufgabe der anzahl von Reihen und Spalten ist Flissend.
		//falls die Anzahl varible sind, schreibt mann 
		//bool[][] bestandInfo = new bool[??][]
		//bitte googeln ;-)
		private bool[,] bestandInfo;

		//UML : Aggregation
		private Medikament[] medikamente; 
		
		//Constructor
		//parameter?????
		public Blister(int anzahlReihen, int anzahlSpalten,long id ,Medikament[] ProduzierteMedikamente)
		{
			this.anzahlReihen = anzahlReihen;
			this.anzahlSpalten = anzahlSpalten;
			this.id = id;
			this.anzahlMulden = anzahlReihen * anzahlSpalten;

			this.bestandInfo = new bool[anzahlReihen,anzahlSpalten];

			this.medikamente = new Medikament[anzahlMulden];
			for (int i = 0; i< ProduzierteMedikamente.Length; i++ )
			{
				if (i < medikamente.Length)
				{
					this.medikamente[i] = ProduzierteMedikamente[i];
				}
				else break;
			}

			for (int i = 0; i < anzahlReihen; i++)
			{
				for (int j = 0; j < anzahlSpalten; j++)
				{
					bestandInfo[i, j] = true;
				}
			}

			for (int i=0;i<medikamente.Length;i++)
			{
				if(medikamente[i] != null)
				{
					anzahlMedikamente++;
				}
			}
		}
		public bool entnehmen(int indexReihe, int indexSpalte)
		{
			if (bestandInfo[indexReihe-1, indexSpalte-1] == true)
			{
				bestandInfo[indexReihe-1, indexSpalte-1] = false;
				return true;
			}
			else return false;
		}
		public void druckeBestandInfo()
		{
			for(int i=0; i<anzahlReihen; i++)
			{
				for(int j=0; j<anzahlSpalten; j++)
				{
					if(bestandInfo[i,j]==true) Console.Write("O ");
					else Console.Write("X ");
				}
				//nechste Reihe.
				Console.Write("\n");
			}
		}
	}
}
