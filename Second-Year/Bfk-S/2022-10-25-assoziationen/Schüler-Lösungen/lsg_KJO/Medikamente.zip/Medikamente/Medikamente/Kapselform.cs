﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Medikamente
{
	class Kapselform : Medikamentenform
	{
		//Attributes
		private double gelMengeInG;

		//Methods
		public Kapselform(double gewichtInG, double laengeInMm, double breiteInMm, long id, double gelMengeInG ):base(gewichtInG, laengeInMm, breiteInMm, id)
		{
			this.gelMengeInG = gelMengeInG;
		}
		public override string wirkstofffreisetzung()
		{
			return "";
		}
	}
}
