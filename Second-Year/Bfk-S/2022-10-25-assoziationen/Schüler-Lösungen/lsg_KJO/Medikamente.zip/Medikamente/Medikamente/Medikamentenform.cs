﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Medikamente
{
	//wenn ein Klasse abstrakte Methode hat, muss die Klasse als 'abstract class' deklariert werden. 
	abstract class Medikamentenform
	{
		//Attributes
		private double gewichtInG;
		private double laengeInMm;
		private double breiteInMm;
		private long id;

		//Constructor
		public Medikamentenform(double gewichtInG, double laengeInMm, double breiteInMm, long id)
		{
			this.gewichtInG = gewichtInG;
			this.laengeInMm = laengeInMm;
			this.breiteInMm = breiteInMm;
			this.id = id;
		}
		//Methods
		//wenn Jemand diese Klasse beerbt, muss die Klasse diese abstrakte Methode implementieren
		public abstract string wirkstofffreisetzung();
	}
}
