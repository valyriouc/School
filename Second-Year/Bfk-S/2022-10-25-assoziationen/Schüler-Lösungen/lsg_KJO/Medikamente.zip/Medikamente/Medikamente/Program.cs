﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Medikamente
{
	class Program
	{
		static void Main(string[] args)
		{
			Console.WriteLine("Aufgabe 1.3.1");
			Medikamentenform t1 = new Tablettenform(2, 8, 3, 1508, 200);

			Console.WriteLine("Aufgabe 1.3.2");
			Medikamentenform t2 = new Tablettenform(3, 7, 2, 3101, 190);
			Medikament medikament = new Medikament("15.08.2025", "Eucaliptum", "Zur Schmerzlinderung bei Bronchialbeschwerden",t2);

			Medikament[] medikamente_t2 = new Medikament[60];
			for (int i=0; i<60; i++)
			{
				medikamente_t2[i] = medikament;
			}

			Console.WriteLine("Aufgabe 1.3.3");
			Blister blister1 = new Blister(2, 6, 2015, medikamente_t2);

			Console.WriteLine("Aufgabe 1.3.4");
			blister1.entnehmen(1, 1);
			blister1.entnehmen(2, 5);

			Console.WriteLine("Aufgabe 1.3.5");
			blister1.druckeBestandInfo();
		}
	}
}
