﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assoziation_Artikel
{
	class Verkaeufer
	{
		//Attributes
		private int VID;
		private List<Artikel> sortiment = new List<Artikel>();

		//Methoden
		public Verkaeufer(int vid)
		{
			VID = vid;
		}
		public double getPreis(int i)
		{
			//sortiment
			Console.WriteLine(
				"Preis von Artikel {0} ist {1} euro."
				, sortiment[i].getName(), sortiment[i].getPreis());
			return sortiment[i].getPreis();
		}
		public void setPreis(int i, double p)
		{
			sortiment[i].setPreis(p);
		}
		public void kaufen(int i, int b)
		{
			sortiment[i].kaufen(b);
		}
		public void rabatt(int s, int d)
		{
			Console.WriteLine("Ab einem Bestellwert von {0} gilt ein Rabatt von {1} %.",s,d);
			foreach(Artikel el in sortiment)
			{
				if (el.getBestand() > s)
				{
					el.setPreis(el.getPreis() - el.getPreis() * d / 100);
				}
			}
		}
		public void erweitereSortiment(int n)
		{
			//?????
		}
		public void addArtikel(Artikel artikel)
		{
			Console.WriteLine("{0} hat auf verkaeufer id (: {1}) hinzugefuegt worden.",artikel, this.VID);
			sortiment.Add(artikel);
		}
		public override string ToString()
		{
			string result = "\n<Aktuelle Artikel Liste>\nVerkaeuferID;Name;Code;Bestand;Preis\n";
			foreach (Artikel el in sortiment)
			{
				result +=string.Format("{0};{1};{2};{3};{4}\n", this.VID, el.getName(), el.getCode(), el.getBestand(), el.getPreis());
			}
			return result; 
		}
	}
}
