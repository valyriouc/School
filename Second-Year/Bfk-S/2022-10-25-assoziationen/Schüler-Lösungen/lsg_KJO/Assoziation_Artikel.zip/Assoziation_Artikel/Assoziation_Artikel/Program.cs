﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assoziation_Artikel
{
	class Program
	{
		static void Main(string[] args)
		{
			Artikel a1 = new Artikel("Hosen", "ho", 300, 100.0);
			Artikel a2 = new Artikel("Tasche", "ta", 100, 100.0);
			Verkaeufer v1 = new Verkaeufer(1);
			v1.addArtikel(a1);
			v1.addArtikel(a2);
			v1.getPreis(1);
			Console.WriteLine(v1.ToString());
			v1.rabatt(150, 5);

			Console.WriteLine(v1.ToString());
		}
	}
}
