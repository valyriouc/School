﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assoziation_Artikel
{
	class Artikel
	{
		//Attribute
		private string name;
		private string code;
		private int bestand;
		private double preis;

		//Konstruktor
		public Artikel()
		{

		}
		public Artikel(string name, string code, int bestand, double preis)
		{
			this.name = name;
			this.code = code;
			this.bestand = bestand;
			this.preis = preis;
		}

		//Methods
		public void setName(string n)
		{
			name = n;
		}
		public string getName()
		{
			return name;
		}
		public void setCode(string c)
		{
			code = c;
		}
		public string getCode()
		{
			return code;
		}
		public void setBestand(int s)
		{
			bestand = s;
		}
		public int getBestand()
		{
			return bestand;
		}
		public void setPreis(double p)
		{
			preis = p;
		}
		public double getPreis()
		{
			return preis;
		}
		public void kaufen(int b)
		{
			this.bestand += b;
			Console.WriteLine("{0} Artikel wird hinzugefuegt. Aktuell Bestand :{1} ",b,bestand);
		}
	}
}
