﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tabletten
{
    internal abstract class Medikamentenform
    {
        public double GewichtInGramm { get; }

        public double LaengeInMillimeter { get; }

        public double BreiteInMillimeter { get; }

        public long Id { get; }

        public Medikamentenform(double gewichtInGramm, double laengeInMillimeter, double breiteInMillimeter, long id)
        {
            GewichtInGramm = gewichtInGramm;
            LaengeInMillimeter = laengeInMillimeter;
            BreiteInMillimeter = breiteInMillimeter;
            Id = id;    
        }

        public abstract string Wirkstofffreisetzung(); 
    }
}
