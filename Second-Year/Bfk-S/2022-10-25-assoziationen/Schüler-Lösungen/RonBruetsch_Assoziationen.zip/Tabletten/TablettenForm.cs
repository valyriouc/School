﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tabletten
{
    internal class TablettenForm : Medikamentenform
    {
        public double PulverKoernungInUm { get; }

        public TablettenForm(
            double gewichtInGramm,
            double laengeInMillimeter,
            double breiteInMillimeter,
            long id,
            double pulverKoernungInUm) : base(gewichtInGramm, laengeInMillimeter, breiteInMillimeter, id)
        {
            PulverKoernungInUm = pulverKoernungInUm;
        }

        public override string Wirkstofffreisetzung()
        {
            return "Schnell";
        }
    }
}
