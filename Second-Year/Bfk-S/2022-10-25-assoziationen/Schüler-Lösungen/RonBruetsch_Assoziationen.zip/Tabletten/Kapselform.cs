﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tabletten
{
    internal class Kapselform : Medikamentenform
    {
        public double GelMengeInGramm { get; }

        public Kapselform(
            double gewichtInGramm, 
            double laengeInMillimeter, 
            double breiteInMillimeter, 
            long id, 
            double gelMengeInGramm) : base(gewichtInGramm, laengeInMillimeter, breiteInMillimeter, id)
        {
            GelMengeInGramm = gelMengeInGramm;
        }

        public override string Wirkstofffreisetzung()
        {
            return "Schneller";
        }
    }
}
