﻿
namespace Tabletten
{
    internal static class Program
    {
        public static void Main()
        {
            TablettenForm tablette = new TablettenForm(2, 8, 3, 1508, 200);

            List<Medikament> medikamente = new List<Medikament>();
            for (int i = 0; i < 60; i++)
            {
                Medikament m = new Medikament("15.08.2025", "Eucaliptum", "Zur Schmerzlinderung bei Bronchialbeschwerden", tablette);
                medikamente.Add(m); 
            }

            Blister blister = new(6, 2, 1,medikamente);

            blister.Entnehmen(1, 1);
            blister.Entnehmen(2, 5);

            blister.DruckeBestandInfo();
        }
    }
}