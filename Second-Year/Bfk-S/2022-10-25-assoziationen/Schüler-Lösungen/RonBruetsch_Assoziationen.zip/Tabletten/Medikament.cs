﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tabletten
{
    internal class Medikament
    {

        public string Haltbarkeitsdatum { get; }

        public string Name { get; }

        public string Wirksamkeit { get; }

        public long Id { get; }

        public Medikamentenform ArzneiForm { get; }

        public Medikament(string haltbarkeitsdatum, string name, string wirksamkeit, Medikamentenform formInfos)
        {
            Haltbarkeitsdatum = haltbarkeitsdatum;
            Name = name;
            Wirksamkeit = wirksamkeit;
            ArzneiForm = formInfos; 
        }
    }
}
