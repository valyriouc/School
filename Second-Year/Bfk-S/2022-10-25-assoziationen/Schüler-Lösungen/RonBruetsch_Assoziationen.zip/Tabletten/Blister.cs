﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Tabletten
{
    internal class Blister
    {
        public int AnzahlMulden { get; }

        public int AnzahlReihen { get; }

        public int AnzahlSpalten { get; }

        public int AnzahlMedikamente { get; private set; }

        public bool[,] BestandInfo { get; } 

        public List<Medikament> Medikamente { get; }

        public long Id { get; }

        public Blister(int anzahlSpalten, int anzahlReihen, int id, List<Medikament> produzierteMedikamente)
        {
            AnzahlSpalten = anzahlSpalten;
            AnzahlReihen = anzahlReihen;
            AnzahlMulden = anzahlReihen * anzahlSpalten;
            Medikamente = new List<Medikament>();
            BestandInfo = new bool[anzahlReihen, anzahlSpalten];


            BlisterBefüllen(produzierteMedikamente);
        }

        private void BlisterBefüllen(List<Medikament> medikamente)
        {
            int count = 0; 
            while (count <= AnzahlMulden)
            {
                count += 1;
                Medikamente.Add(medikamente[count]);
                AnzahlMedikamente += 1;
            }

            for (int y = 0; y < AnzahlReihen; y++)
            {
                for (int x = 0; x < AnzahlSpalten; x++)
                {
                    BestandInfo[y, x] = true;
                }
            }
        }

        public bool Entnehmen(int indexReihe, int indexSpalte)
        {
            try
            {
                if (BestandInfo[indexReihe-1, indexSpalte-1])
                {
                    AnzahlMedikamente -= 1;
                    BestandInfo[indexReihe-1, indexSpalte-1] = false;
                }

                return true;
            }
            catch(Exception)
            {
                return false;
            }
        }

        public void DruckeBestandInfo()
        {
            for (int y = 0; y < AnzahlReihen; y++)
            {
                for(int x = 0; x < AnzahlSpalten; x++)
                {
                    if (!BestandInfo[y,x])
                    {
                        Console.Write("X");
                    }
                    else
                    {
                        Console.Write("O");
                    }
                }
                Console.WriteLine();
            }
        }
    }
}
