﻿// Program.cs -> Main
Random random = new Random();
List<GeoFigur> geoFiguren = new List<GeoFigur>() {
  new Rechteck() { Laenge = random.NextDouble()*50, Hoehe = random.NextDouble()*50 },
  new Quadrat() { SeitenLaenge = random.NextDouble()*50 },
  new Kreis() { Radius = random.NextDouble()*50 },
  new Rechteck() { Laenge = random.NextDouble()*50, Hoehe = random.NextDouble()*50 },
  new Quadrat() { SeitenLaenge = random.NextDouble()*50 },
  new Kreis() { Radius = random.NextDouble()*50}
};
var sum = geoFiguren.Select(x => x.berechneFlaecheninhalt()).Sum();
Console.WriteLine("Summe: " + sum);

// Rechteck.cs
class Rechteck : GeoFigur
{
  public double Laenge { get; set; }
  public double Hoehe { get; set; }

  public double berechneFlaecheninhalt()
  {
    return Laenge * Hoehe;
  }
}


// Quadrat.cs
class Quadrat : GeoFigur
{
  public double SeitenLaenge { get; set; }

  public double berechneFlaecheninhalt()
  {
    return SeitenLaenge * SeitenLaenge;
  }
}

// Kreis.cs
class Kreis : GeoFigur
{
  public double Radius { get; set; }
  public double berechneFlaecheninhalt()
  {
    return Math.PI * Radius * Radius;
  }
}


// GeoFigur.cs
public interface GeoFigur
{
  double berechneFlaecheninhalt();
}
