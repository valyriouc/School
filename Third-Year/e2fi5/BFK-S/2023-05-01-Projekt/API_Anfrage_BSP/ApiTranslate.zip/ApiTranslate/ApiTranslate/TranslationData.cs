﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApiTranslate
{
    public class TranslationData
    {
        public List<Translation> translations {get;set;}
    }
}
