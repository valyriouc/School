﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net.Http.Headers;
using System.Net.Http;



namespace ApiTranslateJSONonly
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("What would you like to translate?");
            translate(Console.ReadLine());
            Console.ReadKey();
        }
        static async void translate(string whatToTranslate)
        {
            var client = new HttpClient();
            var request = new HttpRequestMessage
            {
                Method = HttpMethod.Post,
                RequestUri = new Uri("https://google-translate1.p.rapidapi.com/language/translate/v2"),
                Headers =
                {
                    //Key eindeutig nach Anmeldung bei RapidAPI
                    { "X-RapidAPI-Key", "..." },
                    { "X-RapidAPI-Host", "google-translate1.p.rapidapi.com" },
                },
                Content = new FormUrlEncodedContent(new Dictionary<string, string>
                {
                    { "source", "en" },
                    { "target", "de" },
                    { "q", $"{whatToTranslate}" },
                }),
            };
            using (var response = await client.SendAsync(request))
            {
                response.EnsureSuccessStatusCode();
                var t = await response.Content.ReadAsStringAsync();
                Console.WriteLine(t);
                
                
            }
        }
    }
}
