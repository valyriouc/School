﻿using System.Text;
using System.Xml.Linq;

// =================== CSV to XML ===================
// Umsetzung mit LINQ
var fileName = "Person.csv";
var objectName = fileName.Split('.')[0];

// Die erste line example: Name;Vorname;Alter
var headerKeys = File.ReadLines(fileName).First().Split(';').ToList();

var constructedElements = File.ReadLines(fileName)
.Skip(1)
.Select(line => line.Split(';'))
.Select(values =>
  new XElement(objectName,
    headerKeys.Select((headerKey, index) =>
      new XElement(headerKey, values[index])
    )))
.ToList();

var xdoc = new XDocument(
    new XElement("Alle", constructedElements)
);

xdoc.Save("Daten.xml");



// =================== CSV to XML ===================
// Altenativ String basiert
// Alternative Umsetzung mit String

ConvertCSVToXML("Person.csv", "OutputData.xml");

void ConvertCSVToXML(string inputPath, string outputPath)
{
  using var outputFile = File.OpenWrite(outputPath);
  using var writer = new StreamWriter(outputFile);

  var headers = File.ReadLines(inputPath).First().Split(';').ToList();

  writer.WriteLine("<Alle>");

  foreach (var item in File.ReadLines(inputPath).Skip(1))
  {
    writer.WriteLine(XMLPersonFromCSVLine(headers, item));
  }

  writer.WriteLine("</Alle>");
}

string XMLPersonFromCSVLine(List<string> headers, string line)
{
  var outputXMLObject = new StringBuilder();
  var values = line.Split(';');
  if (values == null || values.Length != headers.Count)
  {
    return "";
  }

  outputXMLObject.AppendLine("<Person>");

  var index = 0;
  foreach (var header in headers)
  {
    outputXMLObject.AppendLine($"<{header}>{values[index]}</{header}>");
    index++;
  }

  outputXMLObject.Append("</Person>");

  return outputXMLObject.ToString();
}